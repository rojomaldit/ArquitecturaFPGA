 
Archivos de inicio para la SD
-----------------------------


Se pueden descargar desde  
https://github.com/raspberrypi/firmware

